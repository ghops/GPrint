package ghops.gprint.models;

import java.time.LocalDate;

public class Print {

    private int id = 0, productId = 0;
    private double meters = 0;
    private Machine machine;
    private LocalDate date;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public double getMeters() {
        return meters;
    }

    public void setMeters(double meters) {
        this.meters = meters;
    }

    public Machine getMachine() {
        return machine;
    }

    public void setMachine(Machine machine) {
        this.machine = machine;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Print init() {
        this.setId(0);
        this.setDate(LocalDate.now());
        this.setMachine(new Machine(0, ""));
        this.setMeters(0);
        return this;
    }

    public void print() {
        System.out.println("id: " + this.getId());
        System.out.println("productId: " + this.getProductId());
        System.out.println("date: " + this.getDate().toString());
        System.out.println("meters: " + this.getMeters());
        System.out.println("machineId: " + this.getMachine().getId());
        System.out.println("machineName: " + this.getMachine().getName());

    }

}
