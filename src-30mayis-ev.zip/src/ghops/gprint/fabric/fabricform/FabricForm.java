package ghops.gprint.fabric.fabricform;

import ghops.gprint.database.FabricDB;
import ghops.gprint.models.Fabric;
import ghops.gprint.models.PrintType;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;

public class FabricForm extends StackPane {

    @FXML
    private Button closeButton;

    @FXML
    private TextField description;

    @FXML
    private TextField name;

    @FXML
    private TextField name2;

    @FXML
    private TextField name3;

    @FXML
    private Button saveButton;



    @FXML
    private CheckBox status;

    @FXML
    private TextField weight;

    @FXML
    private TextField width;

    private Stage window;
    private Fabric fabric;

    public FabricForm(Fabric f) {
        this.fabric = f;
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FabricForm.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
            this.window = new Stage();
            this.window.initModality(Modality.APPLICATION_MODAL);
            this.window.setTitle("Sipariş Formu");
            this.window.initStyle(StageStyle.UTILITY);
            try {
                Scene scene = new Scene(fxmlLoader.load());
                this.window.setScene(scene);
                init();

            } catch (IOException ex) {
                System.out.println(ex);
            }

        } catch (IOException exception) {
            System.err.println(exception);
        }

    }

    public void open() {
        this.window.showAndWait();
    }

    private void init() {

        closeButton.setOnAction((action) -> {
            this.window.close();
        });

        saveButton.setOnAction((action) -> {
            this.setFabric();
            Fabric saved = new FabricDB().add(this.fabric);
            if (saved != null) {
                System.out.println(saved.getId());
            } else {
                System.out.println("kayıt başarısız");
            }
        });

     
    }

    private void setFabric() {
        this.fabric.setName(name.getText());
        this.fabric.setName2(name2.getText());
        this.fabric.setName3(name3.getText());
        if (name2.getText().length() < 1) {
            this.fabric.setName2(null);
        }
        if (name3.getText().length() < 1) {
            this.fabric.setName3(null);
        }
        this.fabric.setDescription(description.getText());
        this.fabric.setPrintType(new PrintType(0, ""));
        this.fabric.setWeight(Integer.parseInt(weight.getText()));
        this.fabric.setWidth(Integer.parseInt(width.getText()));
    }

}
