package ghops.gprint.tools;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.printing.Orientation;

public class ReportPDF {

    private float xPosition = 10;
    private float yPosition = 700;

    
    
    
    
    
    public void write() {
        
        /*
        try (PDDocument document = Loader.loadPDF(new RandomAccessReadBufferedFile("export_sample.pdf"))) {
            for (PDPage page : document.getPages()) {
                System.out.println("sayfa");
            }
        } catch (IOException ex) {
            Logger.getLogger(ReportPDF.class.getName()).log(Level.SEVERE, null, ex);
        }
        /*
      
         */

        try (PDDocument doc = new PDDocument()) {

            PDPage myPage = new PDPage(PDRectangle.LETTER);
            
            doc.addPage(myPage);

            try (PDPageContentStream cont = new PDPageContentStream(doc, myPage)) {

                cont.beginText();

                PDType0Font font = PDType0Font.load(doc, new File("Exo2-Regular.ttf"));
                cont.setFont(font, 12);
                cont.setLeading(14.5f);

                cont.newLineAtOffset(xPosition, yPosition);
                String line1 = "World War II (often abbreviated to WWII or WW2), "
                        + "also known as the Second World War,";
                cont.showText(line1);

                cont.newLine();

                String line2 = "was a global war that lasted from 1939 to 1945, "
                        + "although related conflicts began earlier.";
                cont.showText(line2);
                cont.newLine();

                String line3 = "It involved the vast majority of the world's "
                        + "countries—including all of the great powers—";
                cont.showText(line3);
                cont.newLine();

                String line4 = "eventually forming two opposing military "
                        + "alliances: the Allies and the Axis.";
                cont.showText(line4);
                cont.newLine();

                cont.endText();
            }
            
            doc.save("wwii.pdf");
        } catch (IOException ex) {
            Logger.getLogger(ReportPDF.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}