package ghops.gprint.orders.orderview;

import ghops.gprint.models.Order;
import ghops.gprint.orders.orderitem.OrderItem;
import java.util.List;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.scene.Node;

public class OrderTask extends Task<ObservableList<Node>> {

    private ObservableList<Node> items;
    private List<Order> list;

    public OrderTask(ObservableList<Node> items, List<Order> list) {
        System.out.println(list.size());
        this.items = items;
        this.list = list;
    }

    @Override
    protected ObservableList<Node> call() {
        for (Order order : list) {
            if (isCancelled()) {
                break;
            }
            Platform.runLater(() -> {
                items.add(new OrderItem(order));
            });

            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                System.err.println(ex);
            }
        }
        return items;
    }

}
