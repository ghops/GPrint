package ghops.gprint.customer.customerview;

import ghops.gprint.database.CustomerDB;
import ghops.gprint.models.Customer;
import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;

public class CustomerView extends StackPane {

    @FXML
    private Button addButton;

    @FXML
    private TableColumn<Customer, String> colAddress;

    @FXML
    private TableColumn<Customer, String> colCity;

    @FXML
    private TableColumn<Customer, String> colEmail;

    @FXML
    private TableColumn<Customer, String> colFax;

    @FXML
    private TableColumn<Customer, String> colName;

    @FXML
    private TableColumn<Customer, Boolean> colStatus;

    @FXML
    private TableColumn<Customer, String> colTelephone;

    @FXML
    private TableColumn<Customer, String> colWeb;

    @FXML
    private Button deleteButton;

    @FXML
    private TableView<Customer> table;

    public CustomerView() {

        //last = quantity;
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("CustomerView.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
            init();

        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }

    private void init() {
        this.initTable();
    }

    private void initTable() {
        this.colAddress.setCellValueFactory(new PropertyValueFactory<>("address"));
        this.colCity.setCellValueFactory(new PropertyValueFactory<>("city"));
        this.colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        this.colFax.setCellValueFactory(new PropertyValueFactory<>("fax"));
        this.colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        this.colTelephone.setCellValueFactory(new PropertyValueFactory<>("telephone"));
        this.colWeb.setCellValueFactory(new PropertyValueFactory<>("web"));
        this.colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        this.table.setItems(FXCollections.observableList(new CustomerDB().getAll()));

        this.colStatus.setCellFactory((tableColumn) -> {
            TableCell<Customer, Boolean> tableCell = new TableCell<>() {

                @Override
                protected void updateItem(Boolean t, boolean bln) {
                    super.updateItem(t, bln);
                    if (t != null) {
                        CheckBox cb = new CheckBox();
                        cb.selectedProperty().setValue(t);
                        setGraphic(cb);
                        
                        Customer customer = (Customer) getTableRow().getItem();
                        cb.selectedProperty().addListener((o, oldValue, newValue) -> {
                            System.out.println(customer);
                            customer.setStatus(newValue);
                            new CustomerDB().update(customer);
                        });
                    } else {
                        setGraphic(null);
                    }
                }
            };

            return tableCell;
        });

    }
}
